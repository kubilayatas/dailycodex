t1 = 0:31;
t2 = 0:63;

x = exp(1i*2*pi*(3/2)*t1);
y = cos(2*pi*(3/2)*t2 + (0.25)*pi*t2);

corr1 = x;
corr2 = y;

figure;
subplot(2,1,1);
stem(t1,corr1,'b');
title('Signal 1');

subplot(2,1,2);
stem(t2,corr2,'r');
title('Signal 2');

figure;
subplot(2,1,1);
r = xcorr(corr1,corr2);
stem(r);
title('Cross-Correlation of Signal 1 and Signal 2');

subplot(2,1,2);
c = conv(corr1,-corr2);
stem(c);
title('Convolution of Signal 1 and Signal 2');