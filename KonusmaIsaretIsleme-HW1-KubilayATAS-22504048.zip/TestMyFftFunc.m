t1 = 0:31;
t2 = 0:31;

x = exp(1i*2*pi*(3/2)*t1);
y = cos(2*pi*(3/2)*t2 + (0.25)*pi*t2);

% x = cos(2*pi*(1/2)*t1);
% y = cos(2*pi*(3/2)*t2 + (0.25)*pi*t2);

corr1 = x;
corr2 = y;

figure;
subplot(2,1,1);
% stem(t1,corr1,'b');
stem(corr1,'b');
title('Signal 1');

subplot(2,1,2);
% stem(t2,corr2,'r');
stem(corr2,'r');
title('Signal 2');
saveas(gcf,'Signals_fft.png');

figure;
subplot(2,1,1);
r = xcorr(corr1,corr2);
stem(r);
title('Cross-Correlation of Signal 1 and Signal 2');

subplot(2,1,2);
c = myFFTCorrelation(corr1,corr2);
stem(c);
title('myFFTCorrelation of Signal 1 and Signal 2');
saveas(gcf,'Corr_fft.png');