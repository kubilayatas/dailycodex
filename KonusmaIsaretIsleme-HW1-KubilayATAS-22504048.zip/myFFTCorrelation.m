function corr= myFFTCorrelation(sig1,sig2)

L1=length(sig1);
L2=length(sig2);

N=L1 + L2 -1;

m = max(L1,L2);
if m == L2
    while length(sig1) ~= m
        sig1 = [sig1 0];
    end
else
    while length(sig2) ~= m
        sig2 = [sig2 0];
    end
end

sig2 = fliplr(sig2);
ft1 = fft(sig1,N);
ft2 = fft(sig2,N);
corr = ifft(ft1.*ft2,N);

end