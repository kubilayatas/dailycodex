function corr= myForcedCorrelation(sig1,sig2)
L1=length(sig1);
L2=length(sig2);
corr = zeros(1,L1+L2-1);
sig1 = [zeros(1,L2) sig1 zeros(1,L2)];
sig2 = [sig2 zeros(1,2*L1)];
for i = 1:length(corr)
    corr(i) = sum(sig1.*circshift(sig2,i));
end


end