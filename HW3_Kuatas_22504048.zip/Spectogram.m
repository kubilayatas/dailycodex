clear all
close all
load('AudioRecordings.mat');

x = no_noise_y;
N = length(x);
dF = Fs/N;
f = -Fs/2:dF:Fs/2-dF + (dF/2)*mod(N,2);
X_fft = fftshift(fft(x))/N;
absolute = abs(X_fft);

figure;
plot(x);
grid on;
title('Audio Recording with no noise');
xlabel('Duration');
ylabel('Amplitude');

figure;
plot(f,absolute);
grid on;
title('Audio Recording with no noise');
xlabel('Frequency Hz');
ylabel('Amplitude');

fmax = 8000;
set(gca,'XTick',(-fmax:1000:fmax));
xlim([-fmax fmax]);

x = with_noise_y;
N = length(x);
dF = Fs/N;
f = -Fs/2:dF:Fs/2-dF + (dF/2)*mod(N,2);
X_fft = fftshift(fft(x))/N;
absolute = abs(X_fft);

figure;
plot(x);
grid on;
title('Audio Recording with 1kHz and 440hz sinusoidal noise');
xlabel('Duration');
ylabel('Amplitude');

figure;
plot(f,absolute);
grid on;
title('Audio Recording with 1kHz and 440hz sinusoidal noise');
xlabel('Frequency Hz');
ylabel('Amplitude');

fmax = 8000;
set(gca,'XTick',(-fmax:1000:fmax));
xlim([-fmax fmax]);

sound(no_noise_y,Fs);
pause(10);
sound(with_noise_y,Fs);

figure;
spectrogram(no_noise_y,512,256,512,'yaxis');
figure;
spectrogram(with_noise_y,512,256,512,'yaxis');