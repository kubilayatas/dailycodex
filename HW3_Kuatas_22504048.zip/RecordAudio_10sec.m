Fs = 48000;
recorder = audiorecorder(48000,16,1,-1);
disp('Basla');
record(recorder);
pause(10);
stop(recorder);
disp('Bitti...');
y = getaudiodata(recorder);
plot(y);
sound(y,Fs)

%no_noise = recorder;
%no_noise_y = y;

%with_noise = recorder;
%with_noise_y = y;