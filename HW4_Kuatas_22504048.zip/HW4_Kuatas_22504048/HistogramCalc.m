function hist = HistogramCalc(image)

if length(size(image))>2
    im = rgb2gray(image);
else
    im = image;
end

hist = zeros(1,256);
for i=im(:)'
    hist(i+1) = hist(i+1) + 1;
end

end