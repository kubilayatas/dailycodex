clear all;
clc;
img = rgb2gray(imread('BlueMacaw.jpg'));
hist = HistogramCalc(img);
figure;
subplot(1,2,1);
stem(hist);
xlim(size(hist));
ylim([0 25000]);

subplot(1,2,2);
imshow(img);
saveas(gcf,'Original_Image_and_Histogram.png');

img = HistogramEq(img);
hist2 = HistogramCalc(img);

figure;
subplot(1,2,1);
stem(hist2);
xlim(size(hist2));
ylim([0 25000]);

subplot(1,2,2);
imshow(img);
saveas(gcf,'MyHist_Image_and_Histogram.png');

img = rgb2gray(imread('BlueMacaw.jpg'));
img = histeq(img);

figure;
subplot(1,2,1);
histogram(img);
xlim([0 255]);

subplot(1,2,2);
imshow(img);
saveas(gcf,'MatlabHist_Image_and_Histogram.png');

img = imread('BlueMacaw.jpg');
img_R = img(:,:,1);
img_G = img(:,:,2);
img_B = img(:,:,3);

img_R = histeq(img_R);

figure;
subplot(1,2,1);
histogram(img);
xlim([0 255]);

subplot(1,2,2);
imshow(img);
saveas(gcf,'MatlabHist_Image_and_Histogram.png');