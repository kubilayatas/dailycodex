function image = HistogramEq(image)
if length(size(image))>2
    im = rgb2gray(image);
else
    im = image;
end
im_size = size(im);
hist = HistogramCalc(im);
cdf = cumsum(hist);
cdf = floor((cdf-min(cdf))/(im_size(1)*im_size(2)-min(cdf))*255);

for i = 1:256
im(find(im==(i-1)))=cdf(i); 
end

image = im;

end